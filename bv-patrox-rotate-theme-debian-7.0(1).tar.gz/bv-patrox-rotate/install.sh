#!/bin/bash

THEME_NAME="bv-patrox-rotate"
THEME_DIR="/usr/share/plymouth/themes/$THEME_NAME"
SOURCE_DIR=$(dirname "$(readlink -f "$0")")

if [ "$EUID" -ne 0 ]; then
  echo "bitte als root ausführen (sudo ./install.sh)"
  exit 1
fi

echo "--- starte installation von $THEME_NAME ---"
#reinstall falls es schon da is...
if [ -d "$THEME_DIR" ]; then
    echo "[*] bestehendes theme gefunden. entferne altes theme..."
    rm -rf "$THEME_DIR"
fi

# verzeichnis bauen und dateien neiwerf...
echo "[*] kopiere dateien nach $THEME_DIR..."
mkdir -p "$THEME_DIR"
cp -r "$SOURCE_DIR"/* "$THEME_DIR/"

# rechte und so
echo "[*] setze dateiberechtigungen..."
chmod -R 755 "$THEME_DIR"

# theme bei plymouth registrieren
echo "[*] registriere theme ($THEME_NAME)..."
update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth "$THEME_DIR/$THEME_NAME.plymouth" 100

# theme als standard setzen
echo "[*] setze $THEME_NAME als standard..."
update-alternatives --set default.plymouth "$THEME_DIR/$THEME_NAME.plymouth"

# initramfs aktualisieren
echo "[*] generiere initramfs neu (dauert a weng!)..."
if command -v update-initramfs >/dev/null 2>&1; then
    update-initramfs -u -k all
elif command -v mkinitcpio >/dev/null 2>&1; then
    mkinitcpio -P
else
    echo "[!] warnung: kein bekanntes initramfs-tool gefunden. bitte manuell aktualisieren."
fi

echo "--- installation erfolgreich abgeschlossen! ---"
echo "tipp: du kannst das theme mit 'sudo plymouth-set-default-theme -t $THEME_NAME' prüfen."
echo "---> meist funktioniert das nur bei X11-servern, wenn wayland läuft ist ein neustart das gscheidere!"
